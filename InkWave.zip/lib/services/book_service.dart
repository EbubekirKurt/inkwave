import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:inkwave/models/book.dart';

class BookService {
  static Future<List<Book>> searchBooks(String query) async {
    try {
      final response = await http.get(
        Uri.parse('https://openlibrary.org/search.json?q=$query'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        List<dynamic> docs = data['docs'];

        List<Book> books = docs.map((doc) {
          return Book(
            title: doc['title'] ?? 'Bilinmeyen Başlık',
            author: (doc['author_name'] != null)
                ? doc['author_name'][0]
                : 'Bilinmeyen Yazar',
            imageUrl: (doc['cover_i'] != null)
                ? 'https://covers.openlibrary.org/b/id/${doc['cover_i']}-M.jpg'
                : 'https://via.placeholder.com/128x192.png?text=No+Image',
            rating: (doc['ratings_average'] != null)
                ? double.tryParse(doc['ratings_average'].toString()) ?? 3.5
                : 3.5,
            description: doc['first_sentence'] != null
                ? (doc['first_sentence'] is List
                    ? doc['first_sentence'][0]
                    : doc['first_sentence'])
                : 'Açıklama mevcut değil',
            price: 0.0,
          );
        }).toList();

        return books;
      } else {
        throw Exception('API yanıtı başarısız: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Kitaplar getirilemedi: $e');
    }
  }
}
